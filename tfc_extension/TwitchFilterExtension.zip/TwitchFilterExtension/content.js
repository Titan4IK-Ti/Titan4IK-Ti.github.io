(function() {
    let modal = null;
    let forbiddenWords = ['тест'];

    chrome.storage.sync.get('forbiddenWords', data => {
        forbiddenWords = data.forbiddenWords || ['тест'];
    });

    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.type === "UPDATE_FORBIDDEN_WORDS") {
            forbiddenWords = message.words;
        }
    });

    function createWarningModal() {
        // Удаляем старое модальное окно, если оно есть
        if (modal) {
            modal.remove();
            modal = null;
        }

        const chatSection = document.querySelector('section[data-test-selector="chat-room-component-layout"]');
        if (!chatSection) return;

        modal = document.createElement('div');
        modal.id = 'twitch-ban-modal';
        modal.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #18181b;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px 5px #9147ff, 0 0 40px 10px rgba(145, 71, 255, 0.5);
            z-index: 99999;
            color: white;
            font-family: Arial;
            border: 2px solid #9147ff;
        `;
        
        modal.innerHTML = `
            <p style="margin: 0 0 15px 0; font-size: 18px; font-weight: bold;">ТЫ ЧЕ ДЕЛАЕШЬ, ЗАПРЕЩЕНОЕ СЛОВО!</p>
            <button id="close-modal" style="
                background: #9147ff; 
                border: none; 
                padding: 8px 16px; 
                color: white; 
                border-radius: 5px; 
                cursor: pointer;
                font-weight: bold;
                width: 100%;
            ">извините</button>
        `;
        
        chatSection.appendChild(modal);
        
        // Обработчик для кнопки закрытия
        modal.querySelector('#close-modal').addEventListener('click', () => {
            if (modal) {
                modal.remove();
                modal = null;
            }
        });
    }

    function interceptChat() {
        const chatInput = document.querySelector('div[data-a-target="chat-input"]');
        const sendButton = document.querySelector('button[data-a-target="chat-send-button"]');
        
        if (!chatInput || !sendButton || sendButton.dataset.filterApplied) return;
        
        sendButton.dataset.filterApplied = 'true';

        sendButton.addEventListener('click', (event) => {
            const message = chatInput.innerText.trim().toLowerCase();
            if (forbiddenWords.some(word => message.includes(word))) {
                event.preventDefault();
                event.stopPropagation();
                createWarningModal();
            }
        });

        chatInput.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' && !event.shiftKey) {
                const message = chatInput.innerText.trim().toLowerCase();
                if (forbiddenWords.some(word => message.includes(word))) {
                    event.preventDefault();
                    event.stopPropagation();
                    createWarningModal();
                }
            }
        });
    }

    const observer = new MutationObserver(() => {
        interceptChat();
    });

    observer.observe(document.body, { 
        childList: true, 
        subtree: true 
    });

    interceptChat();
})();