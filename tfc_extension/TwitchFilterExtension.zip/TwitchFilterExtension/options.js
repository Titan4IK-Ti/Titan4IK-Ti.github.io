document.addEventListener('DOMContentLoaded', function() {
    // Default N-words list
    const DEFAULT_NWORDS = [
        'пидор', 'негр', 'хохол', 'москаль', 'русня', 'даун', 'пидр', 
        'педик', 'гомик', 'гомосек', 'черножопый', 'черномазый', 
        'жид', 'узкоглазый', 'чурка', 'хач', 'обезьяна', 'шлюха', 
        'девственник', 'симп', 'инцел', 'пидорас'
    ];

    // DOM elements
    const twitchToggle = document.getElementById('twitchToggle');
    const twitchStatus = document.getElementById('twitchStatus');
    const importDefaultBtn = document.getElementById('importDefaultBtn');
    const wordList = document.getElementById('wordList');

    // Load initial state
    loadSettings();

    // Setup event listeners
    setupEventListeners();

    function loadSettings() {
        chrome.storage.sync.get(['forbiddenWords', 'twitchMode'], function(data) {
            updateUI(data.forbiddenWords || [], data.twitchMode !== false);
            const isTwitchModeOn = data.twitchMode !== false; // Default to true
            updateTwitchModeUI(isTwitchModeOn);
        });
    }

    function setupEventListeners() {
        twitchToggle.addEventListener('click', toggleTwitchMode);
        importDefaultBtn.addEventListener('click', importDefaultWords);
        document.getElementById('addBtn').addEventListener('click', addNewWord);
        document.getElementById('exportBtn').addEventListener('click', exportWords);
        document.getElementById('importBtn').addEventListener('click', () => {
            document.getElementById('importModal').classList.remove('hidden');
        });
        document.getElementById('closeModal').addEventListener('click', () => {
            document.getElementById('importModal').classList.add('hidden');
        });
        document.getElementById('confirmImport').addEventListener('click', importWords);
        document.getElementById('newWord').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') addNewWord();
        });
        document.getElementById('importWords').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') importWords();
        });
    }

    function updateUI(words, isTwitchModeOn = false) {
        const count = document.getElementById('count');
        wordList.innerHTML = '';
        count.textContent = words.length;

        words.forEach(word => {
            const div = document.createElement('div');
            div.className = 'word-item flex justify-between items-center p-3 bg-gray-700 rounded-md hover:bg-gray-600 transition-colors';
            div.innerHTML = `
                <span class="word-text truncate ${isTwitchModeOn ? 'blur-text' : ''}">${word}</span>
                <button class="delete px-3 py-1 bg-red-600 hover:bg-red-700 rounded text-sm transition-colors" data-word="${word}">
                    Delete
                </button>
            `;
            wordList.appendChild(div);
        });

        document.querySelectorAll('.delete').forEach(btn => {
            btn.addEventListener('click', function() {
                const word = this.dataset.word;
                chrome.storage.sync.get(['forbiddenWords', 'twitchMode'], function(data) {
                    const words = (data.forbiddenWords || []).filter(w => w !== word);
                    const twitchMode = data.twitchMode !== false;
                    chrome.storage.sync.set({ forbiddenWords: words }, function() {
                        updateUI(words, twitchMode);
                        notifyContentScripts(words);
                    });
                });
            });
        });
    }

    function notifyContentScripts(words) {
        chrome.tabs.query({ url: "https://www.twitch.tv/*" }, function(tabs) {
            tabs.forEach(tab => {
                chrome.tabs.sendMessage(tab.id, { 
                    type: "UPDATE_FORBIDDEN_WORDS", 
                    words: words 
                }).catch(err => console.log("Tab not ready:", err));
            });
        });
    }

    function addNewWord() {
        const input = document.getElementById('newWord');
        const inputValue = input.value.trim();
        
        if (inputValue) {
            const newWords = inputValue.split(',')
                .map(word => word.trim().toLowerCase())
                .filter(word => word.length > 0);

            if (newWords.length > 0) {
                chrome.storage.sync.get(['forbiddenWords', 'twitchMode'], function(data) {
                    const existingWords = data.forbiddenWords || [];
                    const updatedWords = [...new Set([...existingWords, ...newWords])];
                    const twitchMode = data.twitchMode !== false;
                    chrome.storage.sync.set({ forbiddenWords: updatedWords }, function() {
                        updateUI(updatedWords, twitchMode);
                        notifyContentScripts(updatedWords);
                        input.value = '';
                    });
                });
            }
        }
    }

    function exportWords() {
        chrome.storage.sync.get('forbiddenWords', function(data) {
            const words = data.forbiddenWords || [];
            const wordsString = words.join(', ');
            
            navigator.clipboard.writeText(wordsString).then(function() {
                const notification = document.createElement('div');
                notification.className = 'fixed bottom-4 right-4 bg-green-600 text-white px-4 py-2 rounded-md shadow-lg';
                notification.textContent = 'Copied to clipboard!';
                document.body.appendChild(notification);
                
                setTimeout(() => {
                    notification.classList.add('opacity-0', 'transition-opacity', 'duration-300');
                    setTimeout(() => notification.remove(), 300);
                }, 2000);
            }).catch(err => {
                console.error('Failed to copy: ', err);
            });
        });
    }

    function importWords() {
        const input = document.getElementById('importWords');
        const importedWords = input.value.trim();

        if (importedWords) {
            const newWords = importedWords.split(/[, \n]+/)
                .map(word => word.trim().toLowerCase())
                .filter(word => word.length > 0);
            
            chrome.storage.sync.get(['forbiddenWords', 'twitchMode'], function(data) {
                const existingWords = data.forbiddenWords || [];
                const updatedWords = [...new Set([...existingWords, ...newWords])];
                const twitchMode = data.twitchMode !== false;
                chrome.storage.sync.set({ forbiddenWords: updatedWords }, function() {
                    updateUI(updatedWords, twitchMode);
                    notifyContentScripts(updatedWords);
                    input.value = '';
                    document.getElementById('importModal').classList.add('hidden');
                });
            });
        }
    }

    function importDefaultWords() {
        chrome.storage.sync.get(['forbiddenWords', 'twitchMode'], function(data) {
            const existingWords = data.forbiddenWords || [];
            const updatedWords = [...new Set([...existingWords, ...DEFAULT_NWORDS])];
            const twitchMode = data.twitchMode !== false;
            chrome.storage.sync.set({ forbiddenWords: updatedWords }, function() {
                updateUI(updatedWords, twitchMode);
                notifyContentScripts(updatedWords);
                
                const notification = document.createElement('div');
                notification.className = 'fixed bottom-4 right-4 bg-purple-600 text-white px-4 py-2 rounded-md shadow-lg';
                notification.textContent = 'Default N-words imported!';
                document.body.appendChild(notification);
                
                setTimeout(() => {
                    notification.classList.add('opacity-0', 'transition-opacity', 'duration-300');
                    setTimeout(() => notification.remove(), 300);
                }, 2000);
            });
        });
    }

    function toggleTwitchMode() {
        chrome.storage.sync.get('twitchMode', function(data) {
            const newMode = !(data.twitchMode !== false); // Default to true, then toggle
            chrome.storage.sync.set({ twitchMode: newMode }, function() {
                updateTwitchModeUI(newMode);
                updateWordListBlur(newMode);
                notifyContentScriptsAboutMode(newMode);
            });
        });
    }

    function updateTwitchModeUI(isOn) {
        const toggleIndicator = document.getElementById('toggleIndicator');
        if (isOn) {
            toggleIndicator.classList.remove('translate-x-1', 'bg-gray-400');
            toggleIndicator.classList.add('translate-x-6', 'bg-purple-500');
            twitchStatus.textContent = 'ON';
            twitchStatus.classList.remove('text-gray-400');
            twitchStatus.classList.add('text-purple-400');
        } else {
            toggleIndicator.classList.remove('translate-x-6', 'bg-purple-500');
            toggleIndicator.classList.add('translate-x-1', 'bg-gray-400');
            twitchStatus.textContent = 'OFF';
            twitchStatus.classList.remove('text-purple-400');
            twitchStatus.classList.add('text-gray-400');
        }
    }

    function updateWordListBlur(isEnabled) {
        const wordElements = wordList.querySelectorAll('.word-text');
        wordElements.forEach(element => {
            if (isEnabled) {
                element.classList.add('blur-text');
            } else {
                element.classList.remove('blur-text');
            }
        });
    }

    function notifyContentScriptsAboutMode(isEnabled) {
        chrome.tabs.query({ url: "https://www.twitch.tv/*" }, function(tabs) {
            tabs.forEach(tab => {
                chrome.tabs.sendMessage(tab.id, { 
                    type: "UPDATE_TWITCH_MODE", 
                    enabled: isEnabled 
                }).catch(err => console.log("Tab not ready:", err));
            });
        });
    }
});